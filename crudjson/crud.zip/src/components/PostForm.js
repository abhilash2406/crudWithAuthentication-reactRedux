import React from 'react';

const PostForm = () => {
  
};

export default PostForm;
