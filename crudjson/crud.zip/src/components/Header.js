import React, { useEffect, useState } from 'react';
import { connect } from 'react-redux';
import { GoogleLogin, GoogleLogout } from 'react-google-login';
import { gapi } from 'gapi-script';
import { authentication } from '../actions';

const Header = ({ authDetails, authentication }) => {
  // const authDetails = props.auth;
//   console.log(authDetails);

  const [profile, setProfile] = useState([]);
  const [isLogin, setIslogin] = useState(false);
  const clientId =
    '260034014064-t9k3lhrlke6ocfvt1d69r6nddktpqk34.apps.googleusercontent.com';

  useEffect(() => {
    const initClient = () => {
      gapi.client.init({
        clientId: clientId,
        scope: '',
      });
    };
    gapi.load('client:auth2', initClient);
  });

  const onSuccess = (res) => {
    setIslogin(true);
    setProfile(res.profileObj);
    console.log(res.profileObj.googleId)
    authentication(true, res.profileObj.googleId, res.profileObj.email);
  };

  const onFailure = (err) => {
    console.log('failed', err);
  };

  const logOut = () => {
    setIslogin(false);
    setProfile(null);
    authentication(false, null, null);
  };

  return (
    <div>
      <h2>React Google Login</h2>
      <br />
      <br />
      {isLogin ? (
        <div>
          <img
            src={profile.imageUrl}
            alt="user image ref"
            referrerPolicy="no-referrer"
          />
          <h4>LOGGED USER</h4>
          <p>Name: <small>{profile.name}</small></p>
          <p>Email Address:<small> {profile.email}</small></p>
          <br />
          <br />
          <GoogleLogout
            clientId={clientId}
            buttonText="Log out"
            onLogoutSuccess={logOut}
          />
        </div>
      ) : (
        <GoogleLogin
          clientId={clientId}
          buttonText="Sign in with Google"
          onSuccess={onSuccess}
          onFailure={onFailure}
          cookiePolicy={'single_host_origin'}
          isSignedIn={() => setIslogin(true)}
        />
      )}
    </div>
  );
};

const mapStateToProps = (state) => {
  return {
    authDetails: state.auth,
  };
};

export default connect(mapStateToProps, { authentication })(Header);
