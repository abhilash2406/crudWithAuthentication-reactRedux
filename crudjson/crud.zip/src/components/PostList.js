import React, { useEffect, useState } from 'react';
import _ from 'lodash';
import DataTable from 'react-data-table-component';
import ReactModal from 'react-modal';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import {
  setPosts,
  showForm,
  addPost,
  getPost,
  cancelForm,
  editPost,
  deletePost,
} from '../actions';
import moment from 'moment/moment';
import Form from './Form';

const PostList = ({
  posts,
  setPosts,
  showForm,
  addPost,
  getPost,
  cancelForm,
  editPost,
  deletePost,
  authDetails,
}) => {
  // console.log('posts', posts);
  // console.log(authDetails.isSignedIn);

  const [delModalConfig, setDelModalConfig] = useState({
    showModal: false,
    deleteId: null,
  });

  useEffect(() => {
    if (!posts.onDeleteLoading) {
      setDelModalConfig({
        showModal: false,
        deleteId: null,
      });
    }
  }, [posts.onDeleteLoading]);

  useEffect(() => {
    setPosts();
  }, []);

  ReactModal.setAppElement('#root');

  const [showModal, setShowModal] = useState(true);

  const columns = [
    {
      name: 'ID',
      selector: (row) => row.id,
    },
    {
      name: 'Title',
      selector: (row) => row.title,
      sortable: true,
    },
    {
      name: 'Description',
      selector: (row) => row.body,
    },
    {
      name: 'Created Date',
      selector: (row) =>
        moment(row.createdAt).format('MMMM Do YYYY, h:mm:ss a'),
    },

    {
      omit: authDetails.isSignedIn ? false : true,
      name: 'Action',
      selector: (row) => (
        <div>
          <Link
            type="button"
            className="btn btn-warning"
            onClick={() => onEditRecord(row)}
            to={`/edit/${row.id}`}
          >
            {' '}
            Edit Post
            {posts.onEditLoading && posts.selectedPostId === row.id ? (
              <div
                className="spinner-border spinner-border-sm"
                role="status"
              ></div>
            ) : null}
          </Link>
          <button
            type="button"
            style={{ marginLeft: '10px' }}
            className="btn btn-danger "
            onClick={() => onDelModal(row)}
          >
            Delete
          </button>
        </div>
      ),
    },
  ];
  const onDelModal = (row) => {
    setDelModalConfig({
      showModal: true,
      deleteId: row.id,
    });
  };

  const onCloseModal = (row) => {
    setDelModalConfig({
      showModal: false,
      deleteId: null,
    });
  };
  const onDeleteConfirm = () => {
    deletePost(delModalConfig.deleteId);
  };

  const onEditRecord = (row) => {
    console.log(row.id);
    getPost(row.id);
  };

  const onFormSubmit = (data) => {
    console.log(data);
    if (posts.selectedPostId) {
      editPost(posts.selectedPostId, {
        title: data.title,
        body: data.description,
        updatedAt: new Date().getTime(),
      });
    } else {
      addPost({
        title: data.title,
        body: data.description,
        createdAt: new Date().getTime(),
      });
    }
  };
  return (
    <div>
      <div className="header d-flex justify-content-between align -item-center m-2">
        <h1>POSTS</h1>
        <ReactModal
          isOpen={delModalConfig.showModal}
          contentLabel="Minimal Modal Example"
        >
          <button
            type="button"
            className="btn btn-danger"
            onClick={() => onCloseModal()}
          >
            Close Modal
          </button>
          <button
            type="button"
            className="btn btn-warning"
            onClick={() => onDeleteConfirm()}
          >
            Confirm{''}
            {posts.onDeleteLoading ? (
              <div
                className="spinner-border spinner-border-sm"
                role="status"
              ></div>
            ) : null}
          </button>
        </ReactModal>

        {posts.showForm ? null : authDetails.isSignedIn ? (
          <Link type="button" className="btn btn-primary" to={'/add'}>
            {' '}
            Add Post
          </Link>
        ) : null}
      </div>
      {posts.showForm ? (
        <Form
          onFormSubmit={onFormSubmit}
          selectedPostDetails={posts.selectedPostDetails}
          onCancel={cancelForm}
          onSumbitLoading={posts.addPostLoading}
        />
      ) : (
        <DataTable
          columns={columns}
          data={posts.data}
          pagination
          progressPending={posts.loadingData}
        />
      )}
    </div>
  );
};

const mapStateToProps = (state) => {
  // console.log('state', state);
  return { posts: state.posts, authDetails: state.auth };
};

export default connect(mapStateToProps, {
  setPosts,
  showForm,
  addPost,
  getPost,
  cancelForm,
  editPost,
  deletePost,
})(PostList);
