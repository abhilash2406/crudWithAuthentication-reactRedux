import React, { useEffect, useState } from 'react';
import _ from 'lodash';
import DataTable from 'react-data-table-component';
import { connect } from 'react-redux';
import { cancelForm, editPost, getPost } from '../actions';
import moment from 'moment/moment';
import Form from './Form';

const PostList = ({ posts, cancelForm, editPost, getPost, ...rest }) => {
  // console.log('posts', posts);

  const postId = rest.match.params.id;
  console.log(postId);

  useEffect(() => {
    getPost(postId);                 //getting details of post that to be edited
  }, []);

  const onFormSubmit = (data) => {
    console.log(data);
    editPost(posts.selectedPostId, {
      title: data.title,
      body: data.description,
      updatedAt: new Date().getTime(),
    });
  };
  return (
    <div>
      <div className="header d-flex justify-content-between align -item-center m-2">
        <h1> EDIT POSTS</h1>
      </div>

      <Form
        onFormSubmit={onFormSubmit}
        selectedPostDetails={posts.selectedPostDetails}
        onCancel={cancelForm}
        onSumbitLoading={posts.addPostLoading}
      />
    </div>
  );
};

const mapStateToProps = (state) => {
  // console.log('state', state);
  return { posts: state.posts };
};
export default connect(mapStateToProps, {
  cancelForm,
  editPost,
  getPost,
})(PostList);
