import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import PostList from './PostList';
import PostCreate from './PostCreate';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Router, Route } from 'react-router-dom';
import { resetSuccessMessage } from '../actions';
import history from '../history';
import PostEdit from './PostEdit';
import Header from './Header';
import Loader from './Loader';
import _ from 'lodash';
import PrivateRoute from '../Routes/PrivateRoute';
import PublicRoute from '../Routes/PublicRoute';

const toastConfig = {
  position: 'top-center',
  autoClose: 2000,
  hideProgressBar: false,
  closeOnClick: true,
  pauseOnHover: true,
  draggable: true,
  progress: undefined,
  theme: 'dark',
};

const App = ({ resetSuccessMessage, posts, signin }) => {
  // console.log(authDetails);

  useEffect(() => {
    if (posts.successMessage) {
      toast.success(posts.successMessage, toastConfig);
      resetSuccessMessage();
    }
  }, [posts.successMessage]);
  return (
    <div>
      <ToastContainer />
      <Header />
      {_.isNull(signin) ? (
        <Loader />
      ) : (
        <Router history={history}>
          <PublicRoute
            path="/"
            exact
            isAuthenticated={signin}
            component={PostList}
          ></PublicRoute>
          <PrivateRoute path="/add" isAuthenticated={signin}>
            <PostCreate />
          </PrivateRoute>
          <PrivateRoute path="/edit/:id" isAuthenticated={signin}>
            <PostEdit />
          </PrivateRoute>
        </Router>
      )}
    </div>
  );
};
const mapStateToProps = (state) => {
  return { posts: state.posts, signin: state.auth.isSignIn };
};
export default connect(mapStateToProps, { resetSuccessMessage })(App);
