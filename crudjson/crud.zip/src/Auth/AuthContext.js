import React from 'react';
const AuthApi = React.createContext();
export default AuthApi;